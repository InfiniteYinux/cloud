---
name: Bug Report
about: 确认存在并反馈一个BUG
title: ''
labels: BUG
assignees: ''

---

## 描述
清楚简明地描述错误是什么。
对您期望发生的事情的简洁明了的描述。

## 重现
网址：
截图：

## 环境
Hexo版本：
`package.json`文件：
根目录的`_config.yml`文件：（敏感数据请替换为****）
主题的`_config.yml`文件：
