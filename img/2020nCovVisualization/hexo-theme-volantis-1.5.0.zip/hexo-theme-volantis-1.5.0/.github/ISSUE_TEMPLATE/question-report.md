---
name: Question Report
about: 主题使用遇到问题（通过阅读文档和查看示例博客源码仍无法解决）
title: ''
labels: 疑问
assignees: ''

---

## 描述
清楚简明地描述问题是什么。
对您期望发生的事情的简洁明了的描述。

## 重现
网址：
截图：

## 环境
Hexo版本：
`package.json`文件：
根目录的`_config.yml`文件：（敏感数据请替换为****）
主题的`_config.yml`文件：
